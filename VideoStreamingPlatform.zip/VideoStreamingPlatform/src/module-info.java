/**
 * 
 */
/**
 * 
 */
module VideoStreamingPlatform {
}