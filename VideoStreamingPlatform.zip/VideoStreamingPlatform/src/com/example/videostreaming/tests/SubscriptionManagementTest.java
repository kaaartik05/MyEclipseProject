package com.example.videostreaming.tests;

import com.example.videostreaming.SubscriptionManager;
import com.example.videostreaming.User;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class SubscriptionManagementTest {

    @Test
    public void testUpgradeSubscription() {
        User user = new User("john_doe");
        SubscriptionManager manager = new SubscriptionManager(user);
        manager.upgradePlan("Premium");
        assertEquals("Premium", user.getSubscriptionPlan(), "Subscription plan should be Premium");
    }

    @Test
    public void testRenewSubscription() {
        User user = new User("john_doe");
        SubscriptionManager manager = new SubscriptionManager(user);
        manager.renewSubscription();
        assertTrue(user.getSubscriptionEndDate().isAfter(LocalDate.now()), "Subscription end date should be in the future");
    }

    @Test
    public void testCheckSubscriptionStatus() {
        User user = new User("john_doe");
        SubscriptionManager manager = new SubscriptionManager(user);
        String status = manager.getSubscriptionStatus();
        assertEquals("Active", status, "Subscription status should be Active");
    }
}
