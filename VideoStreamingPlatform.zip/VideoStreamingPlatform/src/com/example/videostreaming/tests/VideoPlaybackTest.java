package com.example.videostreaming.tests;

import com.example.videostreaming.VideoPlayer;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class VideoPlaybackTest {

    @Test
    public void testPlayVideo() {
        VideoPlayer player = new VideoPlayer();
        player.load("video.mp4");
        player.play();
        assertTrue(player.isPlaying(), "Video should be playing");
    }

    @Test
    public void testPauseAndResume() {
        VideoPlayer player = new VideoPlayer();
        player.load("video.mp4");
        player.play();
        player.pause();
        assertFalse(player.isPlaying(), "Video should be paused");
        player.resume();
        assertTrue(player.isPlaying(), "Video should be resumed");
    }

    @Test
    public void testSeek() {
        VideoPlayer player = new VideoPlayer();
        player.load("video.mp4");
        player.play();
        player.seek(30); // Seek to 30 seconds
        assertEquals(30, player.getCurrentPosition(), "Video should be at 30 seconds");
    }

    @Test
    public void testChangeQuality() {
        VideoPlayer player = new VideoPlayer();
        player.load("video.mp4");
        player.setQuality("1080p");
        assertEquals("1080p", player.getQuality(), "Video quality should be set to 1080p");
    }
}
