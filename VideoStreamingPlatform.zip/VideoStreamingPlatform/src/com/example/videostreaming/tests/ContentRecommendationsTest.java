package com.example.videostreaming.tests;

import com.example.videostreaming.RecommendationEngine;
import com.example.videostreaming.User;
import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class ContentRecommendationsTest {

    @Test
    public void testGetRecommendations() {
        User user = new User("john_doe");
        user.setPreferences(Arrays.asList("Action", "Comedy"));
        RecommendationEngine engine = new RecommendationEngine(user);
        List<String> recommendations = engine.getRecommendations();
        assertTrue(recommendations.contains("action_movie_2.mp4"), "Recommendations should include action_movie_2.mp4");
    }
}
