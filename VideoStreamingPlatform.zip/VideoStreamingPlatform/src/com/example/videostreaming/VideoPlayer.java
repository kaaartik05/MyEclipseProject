package com.example.videostreaming;

public class VideoPlayer {
	 private boolean isPlaying;
	    private int currentPosition;
	    private String quality;

	    public void load(String videoFile) {
	        System.out.println("Loading video: " + videoFile);
	        isPlaying = false;
	        currentPosition = 0;
	    }

	    public void play() {
	        isPlaying = true;
	        System.out.println("Playing video...");
	    }

	    public void pause() {
	        isPlaying = false;
	        System.out.println("Pausing video...");
	    }

	    public void resume() {
	        isPlaying = true;
	        System.out.println("Resuming video...");
	    }

	    public void seek(int seconds) {
	        currentPosition = seconds;
	        System.out.println("Seeking to: " + seconds + " seconds");
	    }

	    public void setQuality(String quality) {
	        this.quality = quality;
	        System.out.println("Setting video quality to: " + quality);
	    }

	    public boolean isPlaying() {
	        return isPlaying;
	    }

	    public int getCurrentPosition() {
	        return currentPosition;
	    }

	    public String getQuality() {
	        return quality;
	    }
}
