package com.example.videostreaming;

public class SubscriptionManager {
	  private User user;

	    public SubscriptionManager(User user) {
	        this.user = user;
	    }

	    public void upgradePlan(String plan) {
	        user.setSubscriptionPlan(plan);
	        System.out.println("Upgrading subscription to: " + plan);
	    }

	    public void renewSubscription() {
	        user.setSubscriptionEndDate(LocalDate.now().plusMonths(1));
	        System.out.println("Renewing subscription until: " + user.getSubscriptionEndDate());
	    }

	    public String getSubscriptionStatus() {
	        return LocalDate.now().isBefore(user.getSubscriptionEndDate()) ? "Active" : "Expired";
	    }
}
