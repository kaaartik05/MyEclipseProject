package com.example.videostreaming;

import java.util.ArrayList;
import java.util.List;

public class RecommendationEngine {
	 private User user;

	    public RecommendationEngine(User user) {
	        this.user = user;
	    }

	    public List<String> getRecommendations() {
	        List<String> recommendations = new ArrayList<>();
	        if (user.getPreferences().contains("Action")) {
	            recommendations.add("action_movie_2.mp4");
	        }
	        return recommendations;
	    }
}
