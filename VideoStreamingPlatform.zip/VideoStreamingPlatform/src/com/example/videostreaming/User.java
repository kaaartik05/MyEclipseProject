package com.example.videostreaming;

public class User {
	private String username;
    private String subscriptionPlan;
    private LocalDate subscriptionEndDate;
    private List<String> preferences;

    public User(String username) {
        this.username = username;
        this.subscriptionPlan = "Basic";
        this.subscriptionEndDate = LocalDate.now().plusMonths(1);
    }

    public String getSubscriptionPlan() {
        return subscriptionPlan;
    }

    public void setSubscriptionPlan(String subscriptionPlan) {
        this.subscriptionPlan = subscriptionPlan;
    }

    public LocalDate getSubscriptionEndDate() {
        return subscriptionEndDate;
    }

    public void setSubscriptionEndDate(LocalDate subscriptionEndDate) {
        this.subscriptionEndDate = subscriptionEndDate;
    }

    public List<String> getPreferences() {
        return preferences;
    }

    public void setPreferences(List<String> preferences) {
        this.preferences = preferences;
    }

    public void watch(String videoFile) {
        System.out.println(username + " watched " + videoFile);
    }
}
