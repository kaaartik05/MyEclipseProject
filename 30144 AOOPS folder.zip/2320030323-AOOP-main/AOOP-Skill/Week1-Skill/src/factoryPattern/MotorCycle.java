package factoryPattern;

public class MotorCycle implements Vehicle {

    @Override
    public void drive() {
        System.out.println("I am riding a motorcycle");
    }
}
