package music;

public interface MusicSource {
	void play();
}
