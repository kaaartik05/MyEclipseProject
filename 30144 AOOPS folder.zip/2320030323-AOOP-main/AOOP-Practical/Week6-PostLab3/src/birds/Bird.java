package birds;

public class Bird {
    public void fly() {
        System.out.println("The bird is flying.");
    }
}
