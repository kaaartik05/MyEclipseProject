package auction;

public interface AuctionEvent {
    void update(String message);
}
