package logger;

public enum LogLevel {
    INFO,
    DEBUG,
    ERROR
}
