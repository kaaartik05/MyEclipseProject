package com.example.theme;

public class WebDarkBackground implements Background {
	  @Override
	    public String render() {
	        return "Render Web Dark Background";
	    }
}
