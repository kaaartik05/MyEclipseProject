package com.example.theme;

public interface Background {
	 String render();
}
