package com.example.theme;

public interface ThemeFactory {
	 Button createButton();
	 TextField createTextField();
	 Background createBackground();
}
