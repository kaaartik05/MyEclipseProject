package com.example.theme;

public class WebLightButton implements Button {
	@Override
    public String render() {
        return "Render Web Light Button";
    }
}
