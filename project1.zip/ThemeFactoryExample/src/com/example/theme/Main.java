package com.example.theme;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		        ThemeFactory webLightFactory = new WebLightThemeFactory();
		        ThemeFactory webDarkFactory = new WebDarkThemeFactory();
		        ThemeFactory desktopLightFactory = new DesktopLightThemeFactory();
		        ThemeFactory desktopDarkFactory = new DesktopDarkThemeFactory();

		        System.out.println("Web Light Theme:");
		        createTheme(webLightFactory);

		        System.out.println("\nWeb Dark Theme:");
		        createTheme(webDarkFactory);

		        System.out.println("\nDesktop Light Theme:");
		        createTheme(desktopLightFactory);

		        System.out.println("\nDesktop Dark Theme:");
		        createTheme(desktopDarkFactory);
	}
		 public static void createTheme(ThemeFactory factory) {
		        Button button = factory.createButton();
		        TextField textField = factory.createTextField();
		        Background background = factory.createBackground();

		        System.out.println(button.render());
		        System.out.println(textField.render());
		        System.out.println(background.render());
		    }

}
