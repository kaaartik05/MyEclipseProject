package com.example.theme;

public class DesktopLightTextField implements TextField {
	  @Override
	    public String render() {
	        return "Render Desktop Light TextField";
	    }
}
