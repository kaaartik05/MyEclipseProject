package com.example.theme;

public class DesktopDarkButton implements Button {
	 @Override
	    public String render() {
	        return "Render Desktop Dark Button";
	    }
}
