package com.example.theme;

public class WebLightThemeFactory implements ThemeFactory {
	 @Override
	    public Button createButton() {
	        return new WebLightButton();
	    }

	    @Override
	    public TextField createTextField() {
	        return new WebLightTextField();
	    }

	    @Override
	    public Background createBackground() {
	        return new WebLightBackground();
	    }
}
