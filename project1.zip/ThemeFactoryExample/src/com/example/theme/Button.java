package com.example.theme;

public interface Button {
	 String render();
}
