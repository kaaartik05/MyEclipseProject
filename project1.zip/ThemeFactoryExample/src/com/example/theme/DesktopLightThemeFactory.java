package com.example.theme;

public class DesktopLightThemeFactory implements ThemeFactory{
	@Override
    public Button createButton() {
        return new DesktopLightButton();
    }

    @Override
    public TextField createTextField() {
        return new DesktopLightTextField();
    }

    @Override
    public Background createBackground() {
        return new DesktopLightBackground();
    }
}
