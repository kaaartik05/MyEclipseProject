package com.example.theme;

public class WebLightBackground implements Background{
	 public String render() {
	        return "Render Web Light Background";
	    }
}
