package com.example.theme;

public class DesktopDarkTextField implements TextField {
	 @Override
	    public String render() {
	        return "Render Desktop Dark TextField";
	    }
}
