package com.example.theme;

public class DesktopDarkThemeFactory implements ThemeFactory {
	 @Override
	    public Button createButton() {
	        return new DesktopDarkButton();
	    }

	    @Override
	    public TextField createTextField() {
	        return new DesktopDarkTextField();
	    }

	    @Override
	    public Background createBackground() {
	        return new DesktopDarkBackground();
	    }
}
