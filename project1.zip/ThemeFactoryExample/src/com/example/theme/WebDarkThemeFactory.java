package com.example.theme;

public class WebDarkThemeFactory implements ThemeFactory {
	 @Override
	    public Button createButton() {
	        return new WebDarkButton();
	    }

	    @Override
	    public TextField createTextField() {
	        return new WebDarkTextField();
	    }

	    @Override
	    public Background createBackground() {
	        return new WebDarkBackground();
	    }
}
