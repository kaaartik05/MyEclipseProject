package com.example.theme;

public interface TextField {
	String render();
}
