package com.example.theme;

public class WebDarkButton implements Button{
	  @Override
	    public String render() {
	        return "Render Web Dark Button";
	    }
}
