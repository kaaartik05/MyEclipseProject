package com.example.theme;

public class WebLightTextField implements TextField{
	 public String render() {
	        return "Render Web Light TextField";
	    }
}
