package com.example.theme;

public class DesktopDarkBackground implements Background {
	 @Override
	    public String render() {
	        return "Render Desktop Dark Background";
	    }
}
