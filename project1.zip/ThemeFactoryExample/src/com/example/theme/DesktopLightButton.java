package com.example.theme;

public class DesktopLightButton implements Button {
	  @Override
	    public String render() {
	        return "Render Desktop Light Button";
	    }
}
