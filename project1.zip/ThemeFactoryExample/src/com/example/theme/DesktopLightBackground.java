package com.example.theme;

public class DesktopLightBackground implements Background {
	  @Override
	    public String render() {
	        return "Render Desktop Light Background";
	    }
}
